These files have been compressed into a single ZIP folder for ease of learners
in the Data Carpentry 'Data Analysis and Visualization in Python for Ecologists' lesson, on 2 June 2020.

The following files have been sourced from the Portal Project Teaching Database.
The original data files can be found at: https://figshare.com/articles/Portal_Project_Teaching_Database/1314459

* surveys.csv
* species.csv
* plots.csv
* portal_mammals.sqlite


The following file was sourced from the U.S. Geological Survey.
For additional information, please visit: http://help.waterdata.usgs.gov/policies/provisional-data-statement

* bouldercreek_09_2013.txt


The following files are generated for the lesson.

* speciesSubset.csv
* surveys2001.csv
* surveys2002.csv
